<?php
/**
 * The main template file.
 *
 */
get_header(); ?>
				<!-- SHUT !!-->	
<?php get_footer(); ?>
