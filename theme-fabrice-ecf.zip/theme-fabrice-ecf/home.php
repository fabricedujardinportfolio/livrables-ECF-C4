<?php get_template_part( 'archive' ); ?>
				<!-- Un include de archive  -->	