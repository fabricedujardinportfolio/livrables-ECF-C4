<?php get_template_part( 'parts/newsletter' ); ?>
<?php wp_footer(); ?>
</body>
</html>