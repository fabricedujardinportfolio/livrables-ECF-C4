<form class="newsletter-form container pt-4">
    <p class="text-center">Des offres exclusives, des actus WordPress et du contenu bonus en avant-première</p>
    <div class="col-12 d-block d-md-flex ">  
        <div class="col-md-4"></div>   
        <div class="col-md-4 col-12">        
            <input type="email" name="email" placeholder="E-mail" style="width: inherit;">
            <input type="submit" value="Je m'abonne" style="width: inherit;">
        </div>  
        <div class="col-md-4 col-12"></div>     
    </div>
</form>